package debug

import com.fly.tour.common.BaseApplication

/**
 * Description: <><br>
 * Author:      mxdl<br>
 * Date:        2018/12/27<br>
 * Version:     V1.0.0<br>
 * Update:     <br>
 */
class MeApplication : BaseApplication() {
    override fun onCreate() {
        super.onCreate()
    }
}
