package debug

import android.app.Application

/**
 * Description: <FindApplication><br>
 * Author:      mxdl<br>
 * Date:        2020/2/15<br>
 * Version:     V1.0.0<br>
 * Update:     <br>
 */
/**
 * Description: <FindApplication><br>
 * Author:      mxdl<br>
 * Date:        2020/2/15<br>
 * Version:     V1.0.0<br>
 * Update:     <br>
 */
class FindApplication : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}