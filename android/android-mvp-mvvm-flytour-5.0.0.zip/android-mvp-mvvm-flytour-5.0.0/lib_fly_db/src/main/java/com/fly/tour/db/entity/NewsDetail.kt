package com.fly.tour.db.entity

/**
 * Description: <NewsDetail><br>
 * Author:      mxdl<br>
 * Date:        2019/5/27<br>
 * Version:     V1.0.0<br>
 * Update:     <br>
 */
class NewsDetail {
    var id: Int = 0
    var typeid: Int = 0
    lateinit var title: String
    lateinit var content: String
    lateinit var addtime: String
}
