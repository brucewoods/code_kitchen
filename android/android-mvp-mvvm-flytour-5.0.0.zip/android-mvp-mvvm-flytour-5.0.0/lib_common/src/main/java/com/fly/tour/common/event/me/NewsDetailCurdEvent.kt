package com.fly.tour.common.event.me

import com.fly.tour.common.event.BaseEvent

/**
 * Description: <NewsDetailCurdEvent><br>
 * Author:      mxdl<br>
 * Date:        2019/5/29<br>
 * Version:     V1.0.0<br>
 * Update:     <br>
</NewsDetailCurdEvent> */
class NewsDetailCurdEvent<T>(code: Int) : BaseEvent<T>(code)
