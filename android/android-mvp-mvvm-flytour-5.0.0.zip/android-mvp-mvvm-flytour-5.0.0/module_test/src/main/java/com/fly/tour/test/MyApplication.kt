package com.fly.tour.test

import android.app.Application

/**
 * Description: <MyApplication><br>
 * Author:      mxdl<br>
 * Date:        2020/2/28<br>
 * Version:     V1.0.0<br>
 * Update:     <br>
 */
class MyApplication : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}