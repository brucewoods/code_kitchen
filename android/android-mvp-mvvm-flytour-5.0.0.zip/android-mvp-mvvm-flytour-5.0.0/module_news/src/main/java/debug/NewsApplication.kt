package debug

import android.app.Application

/**
 * Description: <NewsApplication><br>
 * Author:      mxdl<br>
 * Date:        2020/2/15<br>
 * Version:     V1.0.0<br>
 * Update:     <br>
 */
class NewsApplication: Application() {
    override fun onCreate() {
        super.onCreate()
    }
}