package debug

import android.app.Application

/**
 * Description: <><br>
 * Author:      mxdl<br>
 * Date:        2018/12/27<br>
 * Version:     V1.0.0<br>
 * Update:     <br>
 */
class MainApplication : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
